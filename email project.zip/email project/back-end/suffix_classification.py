import pandas as pd

#connect to the data
data = pd.DataFrame
data = pd.read_excel(r"/Users/yinning/Desktop/Sample_Emails.xlsx") #Change path for this


#Create a new column called 'type'
data['type'] = None

# Iterate through each row of the dataframe
for i, row in data.iterrows():
    email = row['Customer Email']
    if '@wku' in email or '@kean' in email:
        data.at[i, 'type'] = 'School'
    else:
        data.at[i, 'type'] = 'Else'

print(data)

#Save this to export the Dataset
data.to_csv("/Users/yinning/Desktop/file1.csv")
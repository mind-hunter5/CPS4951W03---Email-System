package Final;
 
import java.io.*;

public class filter {
    public static void main(String[] args) throws IOException ,InterruptedException {
        //入参
        String arg1 = "";
        String arg2 = "";
        //当前python的SDK位置，和脚本的绝对路径
        String[] arguments = new String[] {"/Users/yinning/PycharmProjects/pythonProject/venv/bin/python", "/Users/yinning/PycharmProjects/pythonProject/毕设email/后缀分类.py" ,arg1,arg2};
        try {
            Process process = Runtime.getRuntime().exec(arguments);
            BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream(),"GBK"));
            String line = null;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
            in.close();
            //process.waitFor()返回值为0表示调用python脚本成功
            //返回值为1表示调用python脚本失败
            int re = process.waitFor();
            System.out.println(re);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
